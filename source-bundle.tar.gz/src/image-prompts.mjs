const base=`Premium children's picture-book illustration, polished warm 3D animated storybook style. NO TEXT, NO LETTERS, NO LOGOS, NO WATERMARKS. The child identity must match image reference 1. Toto must match image reference 2 exactly: white body, blue details, blue cape, glowing gold star on chest, same head/ear/body proportions. Child is always the hero; Toto is smaller companion. Farm outfit after arrival: green long-sleeve shirt, blue denim overalls, brown farm boots. Safe, joyful, age-appropriate composition, no frightening imagery.`;

export const FARM_SCENES=[
`Morning bedroom. Child wakes happily beside sunny window; Toto appears as friendly companion. Home pajamas are acceptable only here.`,
`Farm entrance with both parents behind child. Child asks permission; Toto nearby. Red barn and welcoming farm gate.`,
`Child gently feeds hens and small chicks, deliberately placing grain where smallest chicks can reach. Toto watches.`,
`Shy rabbit scene. Child sits calmly with carrot placed on ground; rabbit approaches voluntarily. Do not depict grabbing or chasing.`,
`Exactly one lost young fawn near trees. Child and Toto notice it calmly and keep safe distance.`,
`Prayer-time transition. Child and father walk toward a mosque/prayer area. Toto remains back near farm fence respectfully and is NOT praying, NOT on a prayer mat, NOT giving religious instruction.`,
`Open barn gate. Child is concerned and thinking; Toto stands beside child. Farmer is NOT present yet.`,
`Honesty scene. Child is visually prominent, speaking to farmer; farmer kneels or bends to child's eye level. Toto supportive beside child.`,
`Exactly one mother deer and one fawn reunite affectionately. Child and Toto watch from a respectful distance.`,
`Child tidies farm tools, water bowls and closes gates responsibly; Toto helps only with ordinary farm task.`,
`Warm family scene. Child thanks both parents; Toto nearby. Affectionate, respectful, calm.`,
`Night farm. Child and Toto sit together under a glowing star; subtle golden key symbol as magical story reward, no text.`
];

export function scenePrompt(page){ return `${base}\nScene ${page}: ${FARM_SCENES[page-1]}\nLandscape 1536x1024. Leave a quiet lower or side area with simple background for later Arabic text overlay.`; }
export function coverPrompt(age){ return `${base}\nBook cover scene: sunny family farm with red barn, hens and chicks, two rabbits, exactly one gentle fawn. Child is clear hero centered, Toto smaller companion. Child apparent age ${age}. Portrait 1024x1536. Leave generous clean upper area for later title overlay.`; }
